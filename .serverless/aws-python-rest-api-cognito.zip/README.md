# Cognito_API_integracao
Implentando controle de acesso a uma API através do AWS Cognito.
